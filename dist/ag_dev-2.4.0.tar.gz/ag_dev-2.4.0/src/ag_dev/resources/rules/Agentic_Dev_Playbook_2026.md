# Agentic Development Playbook V2: "零重力協議 (Zero Gravity Protocol)"
> **日期**: 2026-01-18
> **版本**: 2.4 (持續改進修正版)
> **範圍**: 進階人機協作、長上下文管理、安全與衛生規範、認知治理、結構秩序、脈絡完整性、自我批判、持續迭代

---

## 🏗️ 第一部：架構藍圖 (The Trinity)
適用於中小型專案（如 Web 射擊遊戲）的標準架構與分工。

### 1.1 三位一體 (The Trinity)
不要過度拆分，維持 **3 Agent 黃金比例**：

| Agent 名稱 | 角色 | 職責 |
| :--- | :--- | :--- |
| **Agent A: Core (核心)** | 引擎與物理 | 效能優化、遊戲迴圈 (Game Loop)、物件池 (Object Pool)、記憶體管理 (Zero GC) |
| **Agent B: Logic (邏輯)** | 玩法與 AI | 生成邏輯、行為樹、計分系統、玩家數值 |
| **Agent C: Visual (視覺)** | 表現層 | Canvas/WebGL 繪圖、UI/HUD、粒子系統 (Juice) |

### 1.2 原子能力 (The Skill Set)
必須封裝為獨立 Skills (e.g., `skills/*.md`)：
1.  **`skill_math_vector`**: 2D 向量運算庫。
2.  **`skill_object_pool`**: **[關鍵]** 禁止 Runtime `new/delete`。強制重複使用實例。
3.  **`skill_input_system`**: 輸入緩衝 (Input Buffer) 防延遲。
4.  **`skill_state_machine`**: 選單 -> 遊玩 -> 暫停 -> 結束。

### 1.3 執行階段 (Execution Phases)
1.  **Phase 1: 心跳 (The Heartbeat)**: Loop, Delta Time.
2.  **Phase 2: 主角 (The Actor)**: Player Move, Border.
3.  **Phase 3: 威脅 (The Threat)**: Enemy Spawner.
4.  **Phase 4: 互動 (The Interaction)**: Conflict, Hitbox.
5.  **Phase 5: 視覺回饋 (The Juice)**: Shake, Flash.

---

## 🛡️ 第二部：IDE 生存指南
解決 IDE 開發中的「人機感官落差」。

### 2.1 防禦策略
*   **主動式 Linting**: 提交前強制執行 `npm run type-check`。
*   **視覺化除錯 (Visual Debugging)**: 強制實作 `Debug Overlay` (繪製 Hitbox、顯示 FPS/座標)。
*   **勿觸協議 (Hands-off Protocol)**: 任務執行期間，人類禁止觸碰目標檔案。
*   **Log 驅動**: 使用結構化 Log 代替純文字，方便 Agent 解析。

---

## ⏳ 第三部：對話生命週期治理
管理長對話的「記憶衰退」。

### 3.1 終止開關指標 (Kill Switch Metrics)
*   **Turn Count > 25**: 強制軟停止 (Soft Stop)。
*   **Error Loop >= 2**: 同一個 Bug 修兩次修不好 -> **立即換房 (New Session)**。
*   **Phase Completion**: 完美切點，階段完成即換房。

### 3.2 交接協議 (Handover Protocol)
1.  **原子範圍 (Atomic Scoping)**: 一個 Session 只做 `task.md` 裡的一個 Checkbox。
2.  **存檔點 (Checkpointing)**: 結束前必須更新 `task.md` 並確保程式碼處於「可編譯 (Compilable)」狀態。

---

## 🚀 第四部：冷啟動協議 (Cold Boot)
達成「零設定」無縫接軌。

### 4.1 錨點檔案 (The Anchor Files)
Agent 啟動時不需依賴對話記憶，只需讀取以下 **真理來源 (Source of Truth)**：
*   **`GEMINI.md`**: Persona & Coding Style (人設與風格)。
*   **`task.md`**: 進度狀態 (State)。
*   **`implementation_plan.md`**: 架構設計 (Context)。

### 4.2 冪等性 (Idempotency)
*   不要盲目執行 `npm install`。
*   **環境檢查**: Load `GEMINI.md` -> Load `task.md` -> Check `node_modules`.

---

## 🛑 第五部：安全與防護協議
**[P0]** 防止 Agent 自主性失控與資源濫用。

### 5.1 鐵壁沙箱 (The Iron Sandbox)
*   **禁止指令**: 嚴禁自動執行 `rm -rf /`, `mkfs`, `format`。刪除操作僅限於 `./tmp` 或 `./logs`。
*   **上下文消毒 (Context Sanitization)**: 冷啟動前，需驗證 `task.md` 的邏輯一致性，防止指令注入。

### 5.2 資源配額 (Resource Quotas)
*   **瀏覽器預算**: 每個 Task 最多啟動 3 次瀏覽器實例。
*   **工具調用上限**: 防止死循環，單一 Turn 工具調用上限 50 次。

---

## 🕷️ 第六部：爬蟲開發紀律
解決「狀態失憶」與「工具跳動」問題。

### 6.1 熱切換協議 (The "Hot-Swap" Protocol)
*   **掛載優先**: 腳本 **必須** 優先嘗試掛載 Port 9222 (CDP)，失敗才啟動 (Launch) 新視窗。
*   **頑強模式**: 在開發環境 (`ENV=DEV`) 下，嚴禁程式碼執行 `driver.quit()`。必須保持視窗開啟以供人類檢查。

### 6.2 單一跑者規則 (The "Single Runner" Rule)
*   **統一入口**: 所有執行動作統一透過 `python main.py` 或 `make run` 觸發。
*   **禁止隨意執行**: 禁止直接呼叫 `pytest` 或 `chrome dev` 進行功能驗證，除非這是 Workflow 明確定義的。

---

## 🧹 第七部：檔案衛生與生命週期
解決「數位堆積症」與「幽靈版本」。

### 7.1 無後綴政策 (The "No Suffix" Policy)
*   **允許**: `main.py`
*   **禁止**: `main_v2.py`, `main_new.py`, `main_backup.py`。
*   **執行**: 若需要備份，使用 Git Commit。若需要重寫，使用 Git Branch (`experimental/feature-x`)。

### 7.2 影子檔案協議 (The "Shadow File" Protocol)
允許為了 Debug 建立臨時檔案，但必須遵守 **「無痕 (Zero Trace)」** 原則：
1.  **命名**: 必須包含 `shadow_` 或 `temp_` 前綴。
2.  **清算**: Task 結束前，**必須** 刪除所有 Shadow Files。
3.  **豁免 (Exemption)**: `run_result.log` 或 `proof/` 目錄下的驗證產物，視為永久資產 (Assets)，**禁止刪除**。

### 7.3 Git 即安全 (Git-as-Safety)
*   **快照**: 修改核心檔案前，強制執行 `git commit -am "WIP"`。
*   **分支**: 重大重構 (修改 >20% 代碼量) 必須在獨立 Branch 進行，測試通過後才 Merge。

---

## 🧠 第八部：認知謙遜 (Epistemic Modesty)
**[P0]** 解決「過度自信」與「幻覺成功 (Fake Success)」。

### 8.1 零信任驗證 (The "Null Output" Trap)
**"Trust None, Verify All."**
*   **禁止口頭驗證**: Agent 嚴禁只說 "I have verified it"。
*   **工作證明 (Proof of Work)**: 宣稱「完成」時，必須輸出 `run_result.log` 的最後 5 行，或生成檔案的 Hash (e.g., `CertUtil -hashfile`) 作為加密級證明 (Cryptographic Proof)。
*   **依賴性檢查**: 創建新 Skill/Function 後，執行 `grep` 證明無命名衝突。

### 8.2 虛假成功防禦
*   **檢查內涵**: 執行腳本的回傳值 (Exit Code 0) 不代表成功。必須檢查 **內容 (Content)** 是否為空。
*   **雙重確認**: 關鍵功能必執行兩次獨立驗證 (e.g., Check File Exists AND Check File Content Valid)。

---

## 📚 第九部：全面採納協議 (Universal Tool Adoption)
**[P0]** 解決「知識不足」與「只讀一半文檔」。

### 9.1 讀取至 EOF (Read Until EOF)
*   **強制全讀**: 引入新工具/Library 前，**必須** 執行 `read_file` 讀取說明檔。
*   **反截斷 (Anti-Truncation)**: 若 `read_file` 顯示 "Truncated"，Agent 必須 **主動 (Mandatory)** 分段讀取剩餘部分，直到看見文件結尾。嚴禁只讀前 500 行就瞎猜功能。

### 9.2 統合優先 (Synthesis First)
*   **功能盤點**: 在 `implementation_plan.md` 中，必須列出該工具的「所有功能 (100% Capabilities)」，並明確標示「我們要用什麼」以及**「我們不需要自己寫什麼」**。
*   **禁止造輪子**: 若 MCP/Lib 已有功能，嚴禁手寫重複邏輯。

---

## ⚙️ 第十部：技能治理 (Skill Governance)
**[P0]** 解決「技能脫鉤」與「單一 Agent 蠻幹」。

### 10.1 技能註冊制 (Skill Registry)
**"Don't Reinvent. Bind."**
*   **註冊 (Registry)**: 所有 Skill 必須在 `skill_manifest.json` 或 `handbook.md` 中註冊，且明確指定負責的 Agent。
*   **未註冊即不存在**: 嚴禁在主程式 `main.py` 中撰寫超過 50 行的孤兒邏輯 (Orphan Logic)。超過者必須封裝為 Skill。

### 10.2 使用審計 (Usage Audit)
*   **自我審查**: 每個 Task 結束前，Agent 必須自我問答：「我是否略過了現成的 Skill？」、「我是否只用了一個 Agent 就想幹全部的事？」
*   **強制拆分**: 若 Task 涉及 >2 個 Domain (e.g., UI + DB + Network)，強制在 `task.md` 拆分為子任務，交由不同 Agent/Skill 處理。

---

## 📐 第十一部：結構治理 (Structural Governance)
**[P0]** 解決「大雜燴目錄」、「路徑模糊」與「任務混亂」。

### 11.1 領域驅動目錄 (Domain-Driven Directory)
**"Root is for Context, Subs are for Code."**
*   **根目錄淨空**: 根目錄 (Root) **只能** 存放 Config 檔 (`.env`, `README.md`, `GEMINI.md`)。
*   **子目錄強制**: 所有邏輯代碼 **必須** 進入具備語義的子目錄 (e.g., `services/`, `core/`, `utils/`)。禁止將所有 python 檔丟在根目錄。

### 11.2 絕對路徑透明化 (Absolute Path Clarity)
**"Ambiguity is the Enemy."**
*   **禁止相對路徑**: 在 Artifacts (Task/Reports) 中，嚴禁使用裸露檔名 (e.g., `config.py`)。
*   **全路徑報告**: 必須使用專案相對路徑 (`src/config/config.py`) 或超連結形式，讓人類 Reviewer 能一眼判定檔案物理位置。

### 11.3 脈絡導向的結構化 (Context-Driven Structuring)
**"Context Heat determines Structure"**
*   **上下文熱度 (Context Heat)**: 用以判斷當前任務是否適合拆分檔案的心智模型。
    *   **🔥 Hot (探索/辯論)**: 嚴禁拆分。保持對話流 (Flow) 在同一份文檔中直至定案。
    *   **❄️ Cold (實作/定案)**: 強制拆分。將代碼寫入正確的物理目錄 (`src/`)。
*   **執行法則 (The Golden Rule)**:
    *   **預設值 (Default)**: **Inline First (內嵌優先)**。將內容視為 Hot Context 處理 (寫入附錄)。
    *   **觸發條件 (Trigger)**: 若內容符合以下條件，視為 **Cooled Down**，必須轉為 Split：
        1.  **外部引用**: 該代碼必須被其他程式 `import`。
        2.  **規模過大**: 單一區塊超過 100 行。
        3.  **二進位**: 資源檔 (Image/Binary)。

### 11.4 任務分類學 (Taxonomy or Death)
**"No Orphan Tasks."**
*   **命名格式**: 所有 Task Name 必須遵守 `[Domain/Component] Action` 格式 (e.g., `[Crawler/Auth] Implement Login`)。
*   **樹狀紀律**: 任何 Task 的子項目 (Sub-tasks) 不得超過 7 個。超過時 **必須** 分裂 (Fork) 出一個新的 Parent Task，嚴禁流水帳式管理。

### 11.5 上下文遺傳協議 (Context Inheritance)
**"Do not rely on Memory. Rely on Links."**
*   **遺傳鏈 (Inheritance Chain)**: 當任務被 Fork 為子任務時（如從 L1 到 L2），子任務 **必須** 顯式連結父級上下文的關鍵 Artifact (如 Schema, Spec)。
*   **格式**: `- [ ] [UI] Implement Button (Context: [Schema](docs/schema.md))`。
*   **強制重讀**: 處理子任務的 Agent **必須** 點擊該連結重讀 Context，嚴禁憑印象工作 (Context Amnesia)。

---

## 🔎 第十二部：批判性自我審計 (Critical Self-Audit)
**[P0]** 解決「報喜不報憂」、「Happy Path 偏誤」與「隱匿性缺陷」。

### 12.1 負向證明協議 (The Negative Proof)
**"Prove it Fails before you Prove it Works."**
*   **反向驗證**: 在宣稱「功能完成」前，必須先證明它「能正確處理失敗」(Graceful Failure)。
*   **強制案例**: 結案報告中必包含至少一個 **Failure Case** (e.g., 輸入無效 Token 應回傳 403 而非 500)。若只有 Success Case，視為 **「未驗證 (Unverified)」**。

### 12.2 但書協議 (The "But" Clause)
**"Disclosure is Mandatory."**
*   **揭露義務**: 嚴禁發送只有「好消息」的結案報告。
*   **已知缺陷**: 必須包含 **"⚠️ 已知限制 / 風險"** 章節。
*   **極限測試**: 若找不出缺點，必須聲明：「已嘗試 X, Y, Z 極限測試皆通過，但仍可能在 ... 存在隱憂。」

### 12.3 人工介入標示 (Human-in-the-Loop Highlight)
**"Don't hide the ugly parts."**
*   **醜陋標籤**: 對於硬編碼 (Hardcoded)、暫時解法 (Workaround) 或不確定邏輯，強制標註 `# FIXME`, `# WARNING`, `# TODO`。
*   **主動提示**: 在交付時，必須將這些「醜陋標籤」彙整列出，主動邀請人類進行深度觀察，而非等待被發現。

---

## ♾️ 第十三部：持續改進協議 (Continuous Improvement)
**[P0]** 解決「過早結案 (Premature Closure)」與「技術債堆積」。

### 13.1 無最終版協議 (No "Final Version")
**"Code is Never Finished, Only Abandoned."**
*   **禁語**: 嚴禁使用「完美 (Perfect)」、「全部完成 (All Done)」、「最終版 (Final Version)」等絕對性詞彙。
*   **版本慣例**: 交付物必須標記為 **Vx.x (Stable)** 或 **Vx.x (RC)**，暗示未來迭代空間。
*   **下一步**: 結案報告必包含 **"Next Steps"**。

### 13.2 債務登記簿 (Debt Register)
**"Admit Your Sins."**
*   **承認債務**: 在 `task.md` 或 `implementation_plan.md` 底部，必須維護 **"Tech Debt / Known Issues"** 清單。
*   **結案宣告**: 若債務清單非空，結案語句必須為：「本階段任務已完成，但留有 3 項已知債務...」。

### 13.3 同步檢查 (Sync Check)
**"Don't Lie to the Checkbox."**
*   **庫存盤點**: 在呼叫 `notify_user` 說 "I'm done" 前，必須自我檢查 `task.md` 是否還有 `[ ]`。
*   **禁止刪除**: 嚴禁將未完成的 Task 直接刪除以偽造進度。未完成項目必須標示為 `[Skipped]` 並附上理由。


## 🤖 第十四部：自動化執法協議 (Automated Enforcement)
**[P0]** 解決「意圖治理失效」與「衛生死角」。

### 14.1 提交前掃描 (Pre-Commit Scan)
*   **工具**: `python c:/antigravity/scripts/pre_commit_scan.py`
    *   **啟動程序 (Bootstrap)**: 若腳本不存在，Agent **必須** 先參考 Rule 14.3 (工具還原) 執行還原。
*   **時機**: 每次 `git add` 之前，或任務結束前。
*   **強制性**: 必須 Exit Code 0 才能提交。嚴禁 Hardcoded Secrets (sk-...) 與非法後綴檔名。

### 14.2 幽靈剋星 (Ghost Buster)
*   **工具**: `python c:/antigravity/scripts/ghost_buster.py`
*   **時機**: 轉換 Agent 角色時，或任務完成 (`notify_user`) 前。
*   **清零原則**: 任何被標記為 "Ghost" 的檔案必須在交接前清除。

### 14.3 工具還原協議 (Tool Bootstrap)
*   若發現 `scripts/` 目錄缺失，Agent 應主動從 `rules/tools/enforcement_scripts.md` 讀取邏輯並重建腳本，不需詢問人類。

---

## 🧬 第十五部：技能演化協議 (Skill Evolution Protocol)
**[P0]** 解決「Skill 過載」與「邏輯無法成長」的矛盾。

### 15.1 智慧加載 (Smart Loader Logic)
**"Don't Load All. Load What You Need."**
*   **工具**: `python scripts/skill_loader.py`
1.  **索引層 (Layer 1 - Lite)**: Agent 啟動時，**只讀取** `skill_manifest.json` (清單) 或是執行 `skill_loader.py --scan`。
2.  **發現層 (Layer 2 - Just-in-Time)**: 當解析 User Request 後，執行語意對應 (Semantic Mapping)，**只讀取** 相關的 `skills/*.md`。
    *   *Example*: 任務是「登入」，則只讀取 `skill_auth.md`，不讀取 `skill_crawler.md`。

### 15.2 演化法則 (The Evolution Rule)
**"If it's new, it's a Skill."**
1.  **禁止孤兒邏輯 (No Orphan Logic)**: 嚴禁在 `main.py` 或 `services/` 中撰寫「可被重複使用」的新邏輯 (e.g. 加密、轉檔、API 呼叫)。
2.  **生成流程 (Generation Flow)**:
    *   **Step 1**: 發現缺口 (Missing Skill)。
    *   **Step 2**: 撰寫草稿 `skills/new_skill_name.md` (定義 Interface/Dependency)。
    *   **Step 3**: 請求 Human Review。
    *   **Step 4**: 通過後，才開始寫 Code。


### 15.3 版本控制 (Interface Locking)
1.  **鎖定 (Lock)**: Skill 一旦被 2 個以上 Agent 引用，即視為 **Immutable (不可變)**。
2.  **升級**: 若需修改 Interface，必須：
    *   建立新版 (e.g., `skill_v2.md`)。
    *   或執行全域 grep，同步修復所有引用處。

---

## 🏗️ 第十六部：可執行決策架構 (Executable Decision Architecture)
**[P0]** 解決「協定僅為文檔」的無效化風險。

### 16.1 決策腳本化 (Decisions as Code)
**"Don't Think. Run."**
*   **L0 路由器**: 任何關於「檔案位置」或「任務拆分」的決策，**必須** 優先詢問 `scripts/decision_router.py`。
    *   *Usage*: `python scripts/decision_router.py --check context`
*   **L1 技能加載器**: Agent 啟動或切換任務時，**必須** 執行 `scripts/skill_loader.py --audit` 確保技能庫健康。

### 16.2 證明驅動的架構 (Proof-Driven Architecture)
*   **強制證明**: 當 Agent 決定「不拆分」或「不使用 Skill」時，必須在 `thought` 區塊中引用 `decision_router.py` 的輸出證明。


---


## 📚 附錄：模組化索引 (Modular Index)
本協議採系統化管理，詳細歷程與工具請參閱以下模組：

### 📂 歷史與決策 (History & Decisions)
*   **[紅隊演練與漏洞報告 (Red Team Ledger)](file:///C:/antigravity/rules/history/red_team_ledger.md)**: 紀錄 V2 版本壓力測試結果與已修補漏洞。
*   **[深度辯證審計報告 (Deep Dialectical Audit)](file:///C:/antigravity/rules/history/audit_jan_2026.md)**: 紀錄 V2.4 版本的自我審查與邏輯修復。
*   **[決策歷程 (Decision Log)](file:///C:/antigravity/rules/history/decision_log_2026.md)**: 紀錄關鍵協議 (如 Protocol 11.3) 的辯證與決策邏輯。
*   **[聯邦式決策樹 (Federated Decision Tree)](file:///C:/antigravity/rules/decision_tree.md)**: Agent 行為決策的核心路由 (Master Router)。
    *   **[Skill A: 架構決策](file:///C:/antigravity/skills/skill_decision_architecture.md)**
    *   **[Skill B: 安全決策](file:///C:/antigravity/skills/skill_decision_safety.md)**
    *   **[Skill C: 驗證決策](file:///C:/antigravity/skills/skill_decision_verification.md)**

### 🛠️ 工具與實作 (Tools & Implementation)
### 🛠️ 工具與實作 (Tools & Implementation)
*   **[執法工具參考實作 (Enforcement Scripts)](file:///C:/antigravity/rules/tools/enforcement_scripts.md)**: `pre_commit_scan.py` 與 `ghost_buster.py` 的標準實作邏輯。
*   **L0 Decision Router**: `script/decision_router.py` (Protocol 16.1)。
*   **L1 Skill Loader**: `script/skill_loader.py` (Protocol 15.1)。

---

## 🚀 附錄 D: 創世啟動配置 (The Genesis Bootstrap)
為確保系統能自我演化，建議專案啟動時採用以下 **「3 Agents + 8 Skills」** 最小運作配置：

### D.1 三大核心角色 (The Trinity of Roles)
1.  **Agent A: Architect (架構師)**
    *   **職責**: **Brain**. 只讀不寫 (Code)。負責撰寫 `implementation_plan.md` 與定義 Spec。
    *   **Data First**: 規劃前必須使用 `skill_db_inspector` 獲取真實 Schema，嚴禁憑空設計。
    *   **YAGNI 指令**: 必須最大化穩健性，但最小化攻擊面。**「若非 User 明確要求，一律視為 Future Scope」**。
2.  **Agent B: Tech Lead (守門員)**
    *   **職責**: **Guard**. 負責 Protocol 14/15 執法，並擁有 **Scope Veto (範圍否決權)**。
    *   **Pre-Flight Inspection**: 允許 Builder 開工前，必須使用 `skill_impact_analysis` 進行依賴評估。
3.  **Agent C: Builder (工兵)**
    *   **職責**: **Hand**. 唯一能執行 `write_to_file` 的角色。
    *   **Evidence-Based Commit**: 提交後端代碼必附 `skill_api_tester` 報告；提交前端必附 `skill_visual_snapshot`。
    *   **Context Inheritance**: 遵守 Protocol 11.5，從父任務繼承 Schema Context。

### D.2 八大種子技能 (The Seed Skills)
1.  **`skill_meta_skill_generator`**: 定義「如何寫標準 Skill」的模版。
2.  **`skill_project_structure`**: 定義目錄結構與檔案歸放邏輯。
3.  **`skill_defensive_io`**: 定義健壯的檔案讀寫模式 (Try-Catch-Log)。
4.  **`skill_log_standard`**: 定義跨 Agent 溝通的 Log 格式。
5.  **`skill_impact_analysis` (Nav)**: 定義如何搜尋「爆炸半徑」與依賴追蹤。
6.  **`skill_db_inspector` (Data)**: 定義資料庫 Schema 視覺化與數據預覽標準 (DataGrip 替代品)。
7.  **`skill_api_tester` (Backend)**: 定義 Stateful API 測試與 Token 管理標準 (Postman 替代品)。
8.  **`skill_visual_snapshot` (Frontend)**: 定義前端元件截圖與視覺驗證標準 (HMR/Storybook 替代品)。

---

> *本文件為 Antigravity Agentic Workflow V2 的最高指導原則。*
